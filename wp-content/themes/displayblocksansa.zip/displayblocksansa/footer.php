<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Display Block
 */
?>
<p id="back-top"><a href="#top">Back to Top</a></p>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
        <div class="inner">
            <div class="f-info">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <img src="<?php bloginfo('template_url'); ?>/images/displayblock-logo.png" alt="<?php bloginfo( 'name' ); ?>" class="f-logo">
                </a>
            </div>
            <div class="f-info">
                <h2 class="widget-title">Site</h2>
                <?php wp_nav_menu( array( 'theme_location' => 'secondary-menu' ) ); ?>
            </div>
            <div class="f-info">
                <?php if (!dynamic_sidebar('Footer1')) :?> <?php endif;?>
            </div>
            <div class="f-info">
                <?php if (!dynamic_sidebar('Footer2')) :?> <?php endif;?>
            </div>
            <div class="f-info">
                <?php if (!dynamic_sidebar('Footer3')) :?> <?php endif;?>
            </div>

        </div>

        <div class="site-info">
            <div class="">
                © 2014 display block Ltd. All Rights Reserved. <br>
                Made in the <span class="uk">UK</span>
            </div>

        </div><!-- .site-info -->

	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

<!--GA-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-51176884-1', 'displayblock.com');
  ga('send', 'pageview');

</script>

</body>
</html>