<?php
/**
* Template name: Home
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Display Block
 */

get_header(); ?>
<section class="hero">
  <div class="flexslider">
    <ul class="slides">
      <li>
         <div class="slide-home-enterprise">
          <div class="text-box">
            <h1 class="text-white">Turn on the lights</h1>
            <p class="intro">Fed up dealing with some faceless internet company on the other side of the world? Want someone you can actually talk to? Someone who will manage your campaigns for you at a price you can afford? Choose display block</p>
            <a href="/contact" class="button-white">Contact us</a>
        </div>
      </li>
      <li>
        <div class="slide-home-automation">
         <div class="text-box">
           <h1>Email Marketing without compromise</h1>
           <p class="intro">Just because you’re not Tesco or lastminute.com doesn’t mean you don’t deserve the best in Email Marketing Automation platforms and that’s what you get with display blocks managed email service.</p>
           <a href="/contact" class="button-grey">Contact us</a>
       </div>
      </li>
      <li>
        <div class="slide-home-sme">
         <div class="text-box">
           <h1>Stop Monkeying Around</h1>
           <p class="intro">Your SME deserves beautifully designed, responsive emails, built, tested, and sent out by the professionals but at a cost that makes it a no brainer to outsource.</p>
           <a href="/contact" class="button-grey">Contact us</a>
       </div>
      </li>
    </ul>
  </div>
  <div class="custom-navigation">
    <a href="#" class="flex-prev" title="Previous"><img src="<?php bloginfo('template_url'); ?>/images/prev.svg" alt="Previous"></a>
    <div class="custom-controls-container"></div>
    <a href="#" class="flex-next" title="Next"><img src="<?php bloginfo('template_url'); ?>/images/next.svg" alt="Next"></a>
  </div>
</section>
<section class="sme-intro background-blue big-space">
  <div class="inner">
      <p class="intro">Get started with easy email marketing today. You get your own custom template that you can update with each send. We will take care of everything, from setup to previewing to the final send. This is really hassle free email marketing.</p>

      <h3>Easy Access Set up</h3>
      <p>Free set up includes: branded portal, reporting suite & training, and data import and cleanse.</p>

      <h3>Pro Set up &pound;250</h3>
      <p>As Easy Access Set up but with custom domain set up, ISP feedback loop set up, data cleanse and import.<br>
      display block - managed email marketing for the resource challenged marketer.</p>
    </div>
</section>

<section>
  <div class="banner background-grey big-space home-clients">
    <a href="/brands">
      <h1>Some brands we’ve helped recently</h1>
      <ul class="homepage-client-images">
        <li><img src="<?php bloginfo('template_url'); ?>/images/bmw.png" alt=""></li>
        <li><img src="<?php bloginfo('template_url'); ?>/images/fed-ex.png" alt=""></li>
        <li><img src="<?php bloginfo('template_url'); ?>/images/nike.png" alt=""></li>
        <li><img src="<?php bloginfo('template_url'); ?>/images/tesla.png" alt=""></li>
        <li><img src="<?php bloginfo('template_url'); ?>/images/visa.png" alt=""></li>
      </ul>
      <p>See a more comprehensive list of companies we provide email services for</p>
    </a>
  </div>
</section>


<section>
  <div class="banner background-lightyellow big-space">
    <h1>Get started with your email marketing today</h1>
    <a href="/contact" class="button-grey">Contact us</a>
  </div>
</section>

<section class="home-services">

  <div class="tabs">
    <nav role='navigation' class="transformer-tabs">
      <ul><!--
        --><li>
          <a href="#tab-1" class="active">Enterprise</a>

        </li><!--
         --><li>
         <a href="#tab-2">SME</a>
        </li><!--

      --></ul>
    </nav>

    <div id="tab-2">
    <section class="closertab">
      <section>
        <div class="inner">
          <p class="intro">
            Your SME deserves beautifully designed, responsive emails, built, tested, and sent out by the professionals but at a cost that makes it a no brainer to outsource.
          </p>
          <p>
            Meet display blocks email engineers the experts in managing email campaigns. Fast turn around times with NO compromise. We'll design you a bespoke email template with your header and footer and as many content blocks as you like. Then, every time you want to send an email campaign, send us the copy and the images and we'll build your email, test it, check it renders properly across 30 devices, select the correct list or segment from your data and send it live. We'll then provide you with access to our real-time enterprise level reporting suite so you can monitor your campaign success.
          </p>

          <ul class="how-it-works">
            <li>
              <div class="how-module">
                <div>

                  <img src="<?php bloginfo('template_url'); ?>/images/home-sme_process-1.svg" alt=""></div>
                <p>You get your own beautifully designed template.</p>
              </div>
            </li>
            <li>
              <div class="how-module">
                <div>

                  <img src="<?php bloginfo('template_url'); ?>/images/home-sme_process-2.svg" alt=""></div>
                <p>
                  When you want to email your subscribers just send us the text and images.
                </p>
              </div>
            </li>
            <li>
              <div class="how-module">
                <div>
                  <img src="<?php bloginfo('template_url'); ?>/images/home-sme_process-3.svg" alt=""></div>
                <p>
                  We will prepare, preview and check the email in over 30 different email clients.
                </p>
              </div>
            </li>
            <li>
              <div class="how-module">
                <div>

                  <img src="<?php bloginfo('template_url'); ?>/images/home-sme_process-4.svg" alt=""></div>
                <p>
                  Once you’re happy we will do the sending! No hassle, no fuss. We take care of everything.
                </p>
              </div>
            </li>
          </ul>

          <h3>
            Let the experts in email marketing make sure your email looks exactly how you want it to and gets sent to the right people at the right time. We'll take responsibility for your email going out without compromise.
          </h3>
        </div>
      </section>

      <section class="background-darkblue  big-space">

        <div class="inner">
          <h2 class="text-center">The full offering</h2>

          <p class="intro text-center">We’ll design and build you a bespoke email template incorporating your brand and brand values.</p>

          <p>We’ll use responsive design and coding techniques to ensure the best user experience possible for your recipients and then each time you want to send an email campaign all you have to do is send us your copy and your new images and we'll update your template, re-test it and check that it looks  as it should using the industry standard email rendering tools, Litmus and EmailonAcid.</p>
          <p>We'll prepare your mailing file and update it with any new addresses you might have. Once you have signed off the campaign we'll give it one last check against our internal check list and send it live.</p>

          <h3 class="text-center">What you get for your money</h3>
        </div>
      </section>

      <section>
          <div class="inner">
              <ul class="home-product-descriptions">
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-sme_features-design.svg" alt="">
                  </div>
                  <div>
                    <h4>EMAIL DESIGN AND OPTIMISATION</h4>
                    <p>We will provide you with a briefing document to fill out which will enable us to  design and build the email template you want. Or you can choose a responsive layout from our template library and we will customise it to your brand. We will then test it in Litmus and EmailonAcid to check the rendering across over 30 Email clients, ISP's  and devices and we will optimise your images and host them for you.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-sme_features-data.svg" alt="">
                  </div>
                  <div>
                    <h4>DATA, SEGMENTATION AND CLEANSING</h4>
                    <p>In addition to the real-time reports you'd expect to see on an enterprise email marketing automation platform such as delivery, response and reputation we provide reports on engagement analysis, what devices people are using where in the world they did it. We have split-test reporting so you can test subject lines and creatives and our split test tool will automatically send the winning email to the rest of your data based on your criteria. Email reply management is simple, and handled through an inbox view within the email marketing automation portal.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-sme_features-reporting.svg" alt="">
                  </div>
                  <div>
                    <h4>REAL-TIME REPORTING</h4>
                    <p>Our powerful database management and mining tool allows us to map your data and store your custom field maps for future updates. There is unlimited data storage included in your plan. Our data hygiene tools then clean your data, removing badly formatted email addresses and continues to cleanse your data by removing fatal bounces and feedback loop complaints automatically, ensuring maximum delivery of your good data. Our targeting tools can create email segments based on given or inferred preferences within minutes.</p>
                  </div>
                </li>
                <li>
                  <div>
                    <img src="<?php bloginfo('template_url'); ?>/images/home-sme_features-testing.svg" alt="">
                  </div>
                  <div class="descriptions-picture">
                    <h4>TESTING AND SEND TOOLS</h4>
                    <p>Not only do we use Litmus and EmailonAcid to check that your email looks great everywhere, we check personalisation using our preview tool. We machine validate the HTML, check all the links, and host your images. We can also include send-to-a-friend with a simple merge tag.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-sme_features-email_delivery.svg" alt="">
                  </div>
                  <div>
                    <h4>EMAIL DELIVERY MANAGEMENT</h4>
                    <p>All of these tools are great but mean nothing if your emails blocked by the ISP's and mail filters. We can customise your email sending domain, and provide dedicated IP addresses (additional monthly cost of &pound;100). We will monitor realtime blacklists and your Sender Score reputation from Return Path on all dedicated IP addresses. We automatically handle all your feedback loop complaints from AOL, Yahoo and the Microsoft domains (hotmail, outlook.com, MSN). Your emails are secured with digital signing and monitoring for DKIM and SPF compliance and We encrypted using the TLS (transport layer security) encryption favoured by Gmail. There is also a delivery throttle to enable you to increase or decrease the speed your emails are sent to help build your sender reputation and manage response rates.</p>
                  </div>
                </li>
              </ul>
          </div>
      </section>
      </section>
    </div>

    <div id="tab-1" class="active">
    <section class="closertab">


      <section>
        <div class="inner">
                  <p>Inbox Warriors is display blocks enterprise level EMAP (email marketing automation platform). With it's intuitive drag and drop workflow tool, responsive design wysiwyg and high throughput Power mta's it is suitable for the serious email marketer to do anything from batch and blast to intricate automated email sequences based on user behaviour. With a full macro and micro level reporting suite. You will be supported by the following display block teams, Email production, Email Design and Coding, Data, and your own strategic dedicated account manager.</p>


           <ul class="enterprise-description">
             <li>
               <div class="how-module">
                 <div>
                   <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_process-1.svg" alt=""></div>

                  <!--  <p>Workflow</p> -->
               </div>
             </li>
             <li>
               <div class="how-module">
                 <div>
                   <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_process-2.svg" alt=""></div>

                   <!-- <p>Wysiwyg in action</p> -->
               </div>
             </li>
             <li>
               <div class="how-module">
                 <div>
                   <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_process-3.svg" alt=""></div>

                <!--    <p>Reporting</p> -->
               </div>
             </li>
           </ul>
        </div>
      </section>

           <section class="background-darkblue  big-space">

            <div class="inner">
          <h2 class="text-center">The full offering</h2>

                  <h3 class="text-center">Managed or ASP</h3>

                  <p>Our service is available on an ASP basis, where you log in to our web based SaaS solution and manage all aspects of your email marketing yourself or as a Fully managed service where we look after every aspect of your campaign for you, right down to producing bespoke MIS reports. Most of our clients use a hybrid of the two services and that is where your dedicated strategic account manager can help. We want you to send email so we look to help where ever possible, without the first thing being the sound of our till ringing in your ears.</p>

                <h3 class="text-center">What you get for your money</h3>


                </div>
              </section>
               <section>
          <div class="inner">

            <ul class="home-product-descriptions">
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-broadcasting.svg" alt="">
                  </div>
                  <div>
                    <h4>Bulk email broadcasting</h4>
                    <p>Whether you want to send to a list of 50,000 or 50,000,000 our enterprise level email marketing automation platform provides you with the power and the technology to batch and blast either the same message to all or data driven dynamic content 1-to-1 emails.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-automation.svg" alt="">
                  </div>
                  <div>
                    <h4>Email Marketing Automation</h4>
                    <p>Use dynamic drag and drop workflows to automate all your system driven emails. Autoresponders like order confirmations, welcome emails, nurture programmes, birthday or anniversary or any other nurture or automated sequence of messages, combine this with data driven dynamic content to truly provide powerful targeted 1-to-1 messaging.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-design.svg" alt="">
                  </div>
                  <div>
                    <h4>Email design and optimisation</h4>
                    <p>You can use display blocks in house email design and coding team or choose to do it yourself and you can still design great responsive emails using our drag and drop Email Designer wysiwyg. Choose one of our free responsive templates or start from a blank canvas.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-testing.svg" alt="">
                  </div>
                  <div>
                    <h4>Testing and Send tools</h4>
                    <p>We have you covered here too, with tools like Litmus to check your rendering, personalisation on and off previews within the portal, testing and approval so the design and coding team can test the email but Marketing need to approve it for live. We provide HTML validation, link checking, Gmail promotions tab support, image hosting, custom forms and send to a friend all with a simple to use intuitive GUI.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-data.svg" alt="">
                  </div>
                  <div>
                    <h4>Data, segmentation and cleansing</h4>
                    <p>Our powerful database management and mining tool allows the marketer to easily import data using drag and drop import and field mapping. There is unlimited data storage and you can use our custom field maps or create and save your own for future ease of import. Our data hygiene tools then clean your data on import removing any badly formatted email addresses and continue to cleanse your data removing fatal bounces and feedback loop complaints automatically, ensuring maximum delivery of your good data. Then using our targeting tools you can easily create, within minutes,  segments based on given or inferred preferences based on user data and actions.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-delivery.svg" alt="">
                  </div>
                  <div>
                    <h4>Email delivery management</h4>
                    <p>All of the other tools are great but mean nothing if your emails are getting blocked by the ISP's and filter companies. You can use your customised email sending domain, dedicated or shared IP addresses, we will monitor realtime blacklists and also provide you with your Sender Score from Return Path on all dedicated IP addresses. We automatically handle all your feedback loop complaints from AOL, Yahoo and the Microsoft domains like hotmail. Emails secured with digital signing and monitoring ensures DKIM and SPF issues are highlighted. We can also encrypt your emails using the TLS (transport layer security) encryption favoured by Gmail. There is also a delivery throttle to enable you to increase or decrease the speed your emails are sent to build sender reputation and manage response rates.</p>
                  </div>
                </li>
                <li>
                  <div class="descriptions-picture">
                    <img src="<?php bloginfo('template_url'); ?>/images/home-enterprise_features-reporting.svg" alt="">
                  </div>
                  <div>
                    <h4>Reporting</h4>
                    <p>On top of all the real time reports you'd expect to see on an enterprise email marketing automation platform like, delivery, response and reputation we provide a number of other reports and functions like engagement analysis, what devices people are using when engaged with you, what time and date they engaged and Geo-location telling you where in the world they are when they do it. We have split test reporting meaning you can test subject lines and creatives and our split test win tool will automatically send the winning email to the rest of your data based on your criteria.  Email reply management is simple, and handled through an inbox view within the email marketing automation portal.</p>
                  </div>
                </li>
              </ul>


        </div> <!-- .inner -->

      </section>
    </div>
   </section>
  </div>

  <!-- .tabs -->

</section>

<section class="pattern-background-white">

</section>
<section class="home-subscribe">
  <div class="inner big-space">
    <h1 class="text-center">Subscribe to our newsletter</h1>
    <p class="text-center">Obviously your email address is completely safe with us.</p>

    <form  action="https://cog.displayblock.com/ws_subscribe.php" method="POST">
        <fieldset>
            <!--s related form controls -->
            <legend>Subscribe to our newsletter</legend>
            <!-- defines caption text for form controls that areed by the fieldset element -->
            <ul>
                <li>
                    <label for="firstname">First name</label>
                    <input type="text" name="firstname" placeholder="First name"></li>
                 <li>
                    <label for="lastname">Last name</label>
                    <input type="text" name="lastname" placeholder="Last name"></li>
                <li>
                    <label for="email">Email</label>
                    <input type="email" name="email"  placeholder="Email"></li>
                <li style="display: none">
                    <label for="hiddenfield"></label>
                        <input type="text" name="hiddenfield"></li>
                <li>
                    <label for="subscribe">Subscribe</label>
                    <input type="submit" value="Subscribe" class="button-darkblue"></li>
            </ul>
        </fieldset>
    </form>
  </div>
</section>
<section class="background-grey">
  <div class="inner text-center">
    <h1>What our clients say about us</h1>
  </div>
  <div class="inner">
    <ul class="testimonials">
      <li>
        <div class="testimonial-module">
          <div class="testimonal-picture">
            <img src="<?php bloginfo('template_url'); ?>/images/nicola-atherton.jpg" alt=""></div>
            <blockquote>
              <footer>
                <p class="name">Nicola Atherstone</p>
                <p class="role">Executive Director at Starfish USA</p>
                <p class="quote">Thanks again for your enduring patience and incredible work on all our emails for the Gala. Your teams professionalism and attention to detail are a credit to you.</p>
              </footer>
            </blockquote>
          </div>
      </li>
      <li>
        <div class="testimonial-module">
          <div class="testimonal-picture">
            <img src="<?php bloginfo('template_url'); ?>/images/neil-swan.jpg" alt=""></div>
            <blockquote>
              <footer>
                <p class="name">Neil Swan</p>
                <p class="role">Chief Executive at Starlight Children's Foundation</p>
                <p class="quote">We’ve been sending our email through display block for a number of years, we send over our images and copy and half an hour later there is an email in our inbox to sign off, 5 minutes after sign off it is in our supporters inboxes, works seamlessly.</p>
              </footer>
            </blockquote>
          </div>
      </li>
      <li>
        <div class="testimonial-module">
          <div class="testimonal-picture">
            <img src="<?php bloginfo('template_url'); ?>/images/profile-pic-man.svg" alt=""></div>
            <blockquote>
              <footer>
                <p class="name">John Dryden</p>
                <p class="role">Director at Travel Editions</p>
                <p class="quote">Held our hand from day one and have produced professional, responsive emails every month since. A great service and most importantly superb results with every campaign.</p>
              </footer>
            </blockquote>
          </div>
      </li>
      <li>
        <div class="testimonial-module">
          <div class="testimonal-picture">
            <img src="<?php bloginfo('template_url'); ?>/images/hannah_taylor.jpg" alt=""></div>
            <blockquote>
              <footer>
                <p class="name">Hannah Taylor</p>
                <p class="role">Senior Retention Manager at The White Company</p>
                <p class="quote">The team at display block have taken our emails from flat images to fully responsive mobile-friendly emails resulting in improvements in opens, clicks and revenues.</p>
              </footer>
            </blockquote>
          </div>
      </li>
      <li>
        <div class="testimonial-module">
          <div class="testimonal-picture">
            <img src="<?php bloginfo('template_url'); ?>/images/tim_locke.jpg" alt=""></div>
            <blockquote>
              <footer>
                <p class="name">Tim Locke</p>
                <p class="role">Head of marketing Mark Warner</p>
                <p class="quote">display block’s vision, knowledge and creativity are refreshing. Their can do attitude makes a real difference to Mark Warner’s email marketing.</p>
              </footer>
            </blockquote>
          </div>
      </li>
      <li>
        <div class="testimonial-module">
          <div class="testimonal-picture">
            <img src="<?php bloginfo('template_url'); ?>/images/ray_duggins.jpg" alt=""></div>
            <blockquote>
              <footer>
                <p class="name">Ray Duggins</p>
                <p class="role">Managing Director at All the Jobs</p>
                <p class="quote">I brought my email problems to the team at display block because I knew they’re the experts. Their advice resulted in a 17% email revenue increase.</p>
              </footer>
            </blockquote>
          </div>
      </li>
    </ul>
  </div>
</section>

<?php get_footer(); ?>