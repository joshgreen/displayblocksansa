<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Display Block
 */
?>
<?php the_content(); ?>
