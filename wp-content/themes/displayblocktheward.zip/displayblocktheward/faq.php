<?php
/**
* Template name: FAQ
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Display Block
 */

get_header(); ?>
<div class="faq">
    <div class="max">
        <div class="inner">
            <h4>everything you need to know</h4>
            <h3>Frequently asked questions</h3>
            <dl>
               <dt>How quickly will you get back to me?</dt>

               <dd>We pride our selves on fast, quality serivce so if we can't help you out immediately we will get back to you the same day with an answer. Jobs vary in time to complete depending on their complexity but most jobs can usually be completed the same day.</dd>


                <dt>How soon can you get started?</dt>

                <dd>As soon as we recieve confirmation to go ahead on a job we can get started. So if you're ready and need the job completed the same day we can facilitate this. We have a team of highly experienced people in multiple disciplines so fast quality service is one of the key reasons to use us.</dd>


                <dt>How long will the project take?</dt>

                <dd>Many projects require images assets, links, campaign instructions and some degree of planning but assuming these have been prepared we can usually complete an entire job in a day or less. While we strive to be fast we never compromise on quality of work and are quick to develop tools specific to our clients needs to further help rapid development.</dd>


                <dt>How much does an email build cost?</dt>

                <dd>Email builds can vary greatly depending on what is required for the campaign and well as other varying factors like planning and account management. We also aim to be very competitive when it comes to pricing so to ensure you get the best deal contact our <a href="/contact">head of new business</a>.</dd>


                <dt>Where and who are your clients?</dt>

                <dd>We service clients all over the world although being based in London UK our clients are predominately European. If you require any type of email coding, design or deployment please <a href="/contact">contact us</a> to discuss your project with us.</dd>
            </dl>

        </div> <!-- .inner -->
    </div> <!-- .max -->
</div> <!-- .faq -->

<?php get_footer(); ?>